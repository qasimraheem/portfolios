<?php
include ("../includes/config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin</title>
    <?php
    include ("../includes/meta_css.php");
    ?>
</head>
<body>
<?php
include ("../includes/header.php");
?>
<?php
include ("../includes/nav.php");
?>
<div class="cover_img cover_img-home"></div>
<section class="layout-width layout-padding">
    <h2>Admin</h2>

</section>
<?php
include ("../includes/footer.php");
?>
</body>
</html>