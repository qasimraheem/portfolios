<footer>
    <div class="layout-width">
        &copy;2019, All rights reserved. Terms  of  use of privacy policy.
    </div>
</footer>